from flask import Blueprint, render_template, request, flash

auth = Blueprint('auth', __name__)

@auth.route('/signup', methods=['GET', 'POST'])
def signup ():
    if request.method == 'POST':
      username = request.form.get ('username')
      email = request.form.get ('email')
      password = request.form.get ('password')
      repassword =request.form.get ('repassword')

      if len(username)<2:
          flash('username must be greater than 1 characters.', category='Invalid')
      elif len(email)<4:
           flash('email must be greater than 3 characters.', category='Invalid')
      elif password != repassword:
           flash('Password does not match.', category='Invalid')
      elif len(password)< 8:
           flash('Password must be atleast 8 characters long.', category='Invalid')
      else:
           flash('Account Created!', category='success')
          
          
    return render_template("signup.html")



@auth.route('/login', methods=['GET', 'POST'])
def login():
    return render_template("login.html", boolean= True)

@auth.route('/logout')
def logout():
    return "<p>Logout</p>"

